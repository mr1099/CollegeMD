public class mc 
{
	
	
	public static void main(String[] args) {
		LoadSaveDatabase database = new LoadSaveDatabase();
		
		
		
	}
}