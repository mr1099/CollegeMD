import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class LoadSaveDatabase {

ArrayList<Students> StudentList = new ArrayList();
ArrayList<Professors> ProfessorList = new ArrayList();
ArrayList< Administrators> AdministratorList = new ArrayList();
ArrayList<Courses> CourseList = new ArrayList();

public LoadSaveDatabase() {
	//loads the databases
	LoadStudents();
	LoadProfessors();
	LoadAdministrators();
	LoadClasses();
	//int bubba;
	//System.out.println("What do?");
	//Scanner keyboard = new Scanner(System.in);
	//bubba = keyboard.nextInt();
	
	deleteCourse();
	
	saveStudents();
	saveProfessors();
	saveAdministrators();
	saveClasses();
}

public void LoadStudents() {
	String tempClass = "";
	String tempStatusString = "";
	Character tempStatus = ' ';
	boolean moreClasses = true;
	//tries to open the file and load the information from it
	try {
		System.out.println("I am checking if the user file exists.");
		File readStudents = new File("Students.txt");
		if (readStudents.exists())
		{
			System.out.println("Yay, the user file exists.");
			Scanner inputStudents = new Scanner(readStudents);
			Students tempStudent = new Students();
			while(inputStudents.hasNext()) {
				tempStudent.setID(inputStudents.nextLine());
				//System.out.println("I found a student with ID: " + tempStudent.getID());
				tempStudent.setPass(inputStudents.nextLine());
				tempStudent.setFirst(inputStudents.nextLine());
				tempStudent.setMiddle(inputStudents.nextLine());
				tempStudent.setLast(inputStudents.nextLine());
				tempStudent.setNumberOfClasses(Integer.parseInt(inputStudents.nextLine()));
				
				for(int i = 0; i <tempStudent.getNumberOfClasses();i++)
				{
					tempClass = inputStudents.nextLine();
					
						//System.out.println("The student is taking the class: " + tempClass);
						tempStatus = inputStudents.nextLine().charAt(0);//tempStatusString.charAt(0);
						//System.out.println("Their status for this class is: " + tempStatus);
						tempStudent.setClass(tempClass, tempStatus);
						//System.out.println(tempStudent.getClassNumber());
				}
		
				StudentList.add(new Students(tempStudent));
				System.out.println("I added a student. we now have: " + StudentList.size());
			}inputStudents.close();
			
		} else { //if the file doesn't exist it creates the file
			PrintWriter outputStudents = new PrintWriter("Students.txt");
			outputStudents.close();
		}
	
	}
	//catches any exceptions
	catch (Exception e) {
		System.out.println(e.toString());
	}
	//shows what information was saved
	for(int i = 0; i < StudentList.size(); i++)
	{
		System.out.println("ID: " + StudentList.get(i).getID());
		System.out.println("Password: " + StudentList.get(i).getPass());
		System.out.println("Name: "+ StudentList.get(i).getFirst() + " " + StudentList.get(i).getMiddle() + " " + StudentList.get(i).getLast());
		System.out.println("This person is taking this many classes: " + StudentList.get(i).getNumberOfClasses());
		for(int j = 0; j < StudentList.get(i).getNumberOfClasses(); j++)
		{
			
			System.out.println("Class: " + StudentList.get(i).getClass(j));
			
			System.out.println("Status: " + StudentList.get(i).getClassStatus(j));
		}	
	}
	
	
}

public void LoadProfessors() {
	String tempClass = "";
	
	boolean moreClasses = true;
	//tries to open the file and load the information
	try {
		System.out.println("I am checking if the professor file exists.");
		File readProfessors = new File("Professors.txt");
		if (readProfessors.exists())
		{
			System.out.println("Yay, the Professor file exists.");
			Scanner inputProfessors = new Scanner(readProfessors);
			
			Professors tempProfessor = new Professors();
			
			while(inputProfessors.hasNext()) {
				tempProfessor.setID(inputProfessors.nextLine());
				//System.out.println("I found a student with ID: " + tempStudent.getID());
				tempProfessor.setPass(inputProfessors.nextLine());
				tempProfessor.setFirst(inputProfessors.nextLine());
				tempProfessor.setMiddle(inputProfessors.nextLine());
				tempProfessor.setLast(inputProfessors.nextLine());
				tempProfessor.setNumberOfClasses(Integer.parseInt(inputProfessors.nextLine()));
				
				for(int i = 0; i <tempProfessor.getNumberOfClasses();i++)
				{
					
					tempClass = inputProfessors.nextLine();
						tempProfessor.setClass(tempClass);
				}
		
				ProfessorList.add(new Professors(tempProfessor));
				System.out.println("I added a professor. we now have: " + ProfessorList.size());
			}inputProfessors.close();
			
		} else { //if the file doesn't exist it creates it
			System.out.println("The file didnt exist.");
			PrintWriter outputProfessors = new PrintWriter("Professors.txt");
			outputProfessors.close();
		}
	
	}
	catch (Exception e) {
		System.out.println(e.toString());
	}
	//displays the information loaded
	/*for(int i = 0; i < ProfessorList.size(); i++)
	{
		System.out.println("ID: " + ProfessorList.get(i).getID());
		System.out.println("Password: " + ProfessorList.get(i).getPass());
		System.out.println("Name: "+ ProfessorList.get(i).getFirst() + " " + ProfessorList.get(i).getMiddle() + " " + ProfessorList.get(i).getLast());
		System.out.println("This person is teaching this many classes: " + ProfessorList.get(i).getNumberOfClasses());
		for(int j = 0; j < ProfessorList.get(i).getNumberOfClasses(); j++)
		{
			
			System.out.println("Class: " + ProfessorList.get(i).getClass(j));
		}	
	}*/
	
		
}

public void LoadAdministrators() {

	
	
	try {
		//tries to open the file and load the information
		System.out.println("I am checking if the file administrator exists.");
		File readAdministrators = new File("Administrators.txt");
		if (readAdministrators.exists())
		{
			System.out.println("Yay, the Professor file exists.");
			Scanner inputAdministrators = new Scanner(readAdministrators);
			
			Administrators tempAdministrator = new Administrators();
			
			while(inputAdministrators.hasNext()) {
				tempAdministrator.setID(inputAdministrators.nextLine());
				//System.out.println("I found a student with ID: " + tempStudent.getID());
				tempAdministrator.setPass(inputAdministrators.nextLine());
				tempAdministrator.setFirst(inputAdministrators.nextLine());
				tempAdministrator.setMiddle(inputAdministrators.nextLine());
				tempAdministrator.setLast(inputAdministrators.nextLine());
				
				
				AdministratorList.add(new Administrators(tempAdministrator));
				System.out.println("I added an administrator. we now have: " + AdministratorList.size());
			}inputAdministrators.close();
			
		} else { //if the file does not exist it creates it
			System.out.println("The file didnt exist.");
			PrintWriter outputAdministrators = new PrintWriter("Administrators.txt");
			outputAdministrators.close();
		}
	
	}
	catch (Exception e) {
		System.out.println(e.toString());
	}
	/*for(int i = 0; i < AdministratorList.size(); i++)
	{
		System.out.println("ID: " + AdministratorList.get(i).getID());
		System.out.println("Password: " + AdministratorList.get(i).getPass());
		System.out.println("Name: "+ AdministratorList.get(i).getFirst() + " " + AdministratorList.get(i).getMiddle() + " " + AdministratorList.get(i).getLast());	
	}*/
}

public void saveStudents()
{
	try
	{
		//opens the file and saves the student information
		PrintWriter pw = new PrintWriter("Students.txt");
		
		for(int i = 0; i < StudentList.size(); i++)
		{
			pw.println(StudentList.get(i).getID());
			System.out.println("Saving ID: " + StudentList.get(i).getID());
			pw.println(StudentList.get(i).getPass());
			pw.println(StudentList.get(i).getFirst());
			pw.println(StudentList.get(i).getMiddle());
			pw.println(StudentList.get(i).getLast());
			pw.println(Integer.toString(StudentList.get(i).getNumberOfClasses()));
			for(int j = 0; i < StudentList.get(i).getNumberOfClasses(); j++)
			{
				pw.println(StudentList.get(i).getClass(j));
				pw.println(StudentList.get(i).getClassStatus(j));
			}
		}
		//closes the file and handles any errors
		pw.close();
	} 
	catch (Exception e)
	{
		
	}
	
}

public void saveProfessors()
{
	try
	{
		//opens the file and saves the professors information
		PrintWriter pw = new PrintWriter("Professors.txt");
		
		for(int i = 0; i < ProfessorList.size(); i++)
		{
			pw.println(ProfessorList.get(i).getID());
			pw.println(ProfessorList.get(i).getPass());
			pw.println(ProfessorList.get(i).getFirst());
			pw.println(ProfessorList.get(i).getMiddle());
			pw.println(ProfessorList.get(i).getLast());
			pw.println(ProfessorList.get(i).getNumberOfClasses());
			for(int j = 0; j < ProfessorList.get(i).getNumberOfClasses(); j++)
			{
				pw.println(ProfessorList.get(i).getClass(j));
			}
		}
		//closes the file and handles any errors
		pw.close();
	}
	catch (Exception e)
	{
		
	}
}

public void saveAdministrators()
{
	try
	
	{
		//opens the file and saves the administrators information
		PrintWriter pw = new PrintWriter("Administrators.txt");
		
		for(int i = 0; i < AdministratorList.size(); i++)
		{
			pw.println(AdministratorList.get(i).getID());
			pw.println(AdministratorList.get(i).getPass());
			pw.println(AdministratorList.get(i).getFirst());
			pw.println(AdministratorList.get(i).getMiddle());
			pw.println(AdministratorList.get(i).getLast());
		}
		//closes the file and handles any errors
		pw.close();
	}
	catch (Exception e)
	{
		
	}
}

public void LoadClasses()
{
	String tempStudent;
	try
	{
		System.out.println("Checking to see if the course file exists.");
		File readCourses = new File("Courses.txt");
		if(readCourses.exists())
		{
			System.out.println("Yay the course file exists.");
			Scanner inputCourses = new Scanner(readCourses);
			Courses tempCourse = new Courses();
			while(inputCourses.hasNext())
			{
				System.out.println("There is something in the course file.");
				tempCourse.setCourseName(inputCourses.nextLine());
				tempCourse.setProfessor(inputCourses.nextLine());
				tempCourse.setCourseNumber(inputCourses.nextLine());
				tempCourse.setNumberOfStudents(Integer.parseInt(inputCourses.nextLine()));
				
				for(int i = 0; i < tempCourse.getNumberOfStudents(); i++)
				{
					tempCourse.setRoster(inputCourses.nextLine());
				}
				CourseList.add(new Courses(tempCourse));
				System.out.println("Created a new course.");
			}
			inputCourses.close();
		}else{PrintWriter outputStudents = new PrintWriter("Courses.txt");
		outputStudents.close();
		}
	}
	catch (Exception e)
	{
		System.out.println(e.toString());
	}
	
}

public void saveClasses()
{
	try
	{
	PrintWriter pw = new PrintWriter("Courses.txt");
	
	for(int i = 0; i < CourseList.size(); i++)
	{
		pw.println(CourseList.get(i).getCourseName());
		pw.println(CourseList.get(i).getProfessor());
		pw.println(CourseList.get(i).getCourseNumber());
		pw.println(CourseList.get(i).getNumberOfStudents());
		for(int j = 0; j < CourseList.get(i).getNumberOfStudents(); j++)
		{
			pw.println(CourseList.get(i).getRosterStudents(j));
		}
	System.out.println("Saving a class.");
	}
	pw.close();
	}
	catch (Exception e)
	{
		
	}
}

public void deleteCourse()
{
	
	
	
	
	//add deleting if the id matches etc.  currently only does if the name matches
	
	
	
	
	Scanner keyboard= new Scanner(System.in);
	String classSearch = "";
	String currentClass = "";
	boolean found = false;
	boolean foundSomething = false;
	int courseNum = 0;
	
	System.out.println("Please enter the name or number of the class you want to delete.");
	classSearch = keyboard.nextLine();
	
	System.out.println("Results of your search of: " + classSearch);
	
	for(int i = 0; i < CourseList.size(); i++)
	{
		currentClass = CourseList.get(i).getCourseName();
		
		found = currentClass.toUpperCase().indexOf(classSearch.toUpperCase()) != -1;
		
		if (found == false)
		{
			currentClass = CourseList.get(i).getCourseNumber();
			found = currentClass.toUpperCase().indexOf(classSearch.toUpperCase()) != -1;
		}
		if(found)
		{
			foundSomething = true;
			System.out.println("FOUND: " + CourseList.get(i).getCourseNumber() + " - " + CourseList.get(i).getCourseName());
			System.out.println("ID number: " + i);
			found = false;
		}
			
	}
	if(foundSomething)
	{
		System.out.print("Enter the id number of the class you want to delete.");
		courseNum = keyboard.nextInt();
		CourseList.remove(courseNum);
	}
}

public void editCourse()
{
	Scanner keyboard= new Scanner(System.in);
	String classSearch = "";
	String currentClass = "";
	boolean found = false;
	boolean foundSomething = false;
	int courseNum = 0;
	boolean done = false;
	int editNum = 0;
	char finished = ' ';
	
	
	
	System.out.println("Please enter the name or number of the class you want to edit.");
	classSearch = keyboard.nextLine();
	
	System.out.println("Results of your search of: " + classSearch);
	
	for(int i = 0; i < CourseList.size(); i++)
	{
		currentClass = CourseList.get(i).getCourseName();
		
		found = currentClass.toUpperCase().indexOf(classSearch.toUpperCase()) != -1;
		
		if (found == false)
		{
			currentClass = CourseList.get(i).getCourseNumber();
			found = currentClass.toUpperCase().indexOf(classSearch.toUpperCase()) != -1;
		}
		
		if(found)
		{
			foundSomething = true;
			System.out.println("FOUND: " + CourseList.get(i).getCourseNumber() + " - " + CourseList.get(i).getCourseName());
			System.out.println("ID number: " + i);
			found = false;
		}
			
	}
	if(foundSomething)
	{
		System.out.print("Enter the id number of the class you want to edit.");
		courseNum = keyboard.nextInt();
		done = false;
		while (done == false)
		{
			System.out.println("Enter the number for what you want to edit.");
			System.out.println("1.  Course Name\n" + 
			"2.  Professor\n" + "3.  Description");
			
			editNum = keyboard.nextInt();
			
			if(editNum == 1)
			{
				System.out.println("Enter the new Course name");
				CourseList.get(courseNum).setCourseName(keyboard.nextLine());
			}
			if(editNum == 2)
			{
				System.out.println("Enter the new Course Professor");
				CourseList.get(courseNum).setProfessor(keyboard.nextLine());
			}
			if(editNum == 3)
			{
				System.out.println("Enter the new Course description");
				CourseList.get(courseNum).setDescription(keyboard.nextLine());
			}
			System.out.println("Press 1 if you would like to edit another part of the class. press any key to exit.");
			finished = keyboard.nextLine().charAt(0);
			if (finished == '1')
			{
				done = true;
			}
		}
	}
}



}